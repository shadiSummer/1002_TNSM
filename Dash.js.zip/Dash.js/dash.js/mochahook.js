require("babel/register")({
    ignore: /node_modules/,
});