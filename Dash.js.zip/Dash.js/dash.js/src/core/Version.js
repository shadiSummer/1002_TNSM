const VERSION = '2.5.0';
export function getVersionString() {
    return VERSION;
}
